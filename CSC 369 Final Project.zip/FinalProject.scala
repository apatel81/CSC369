//package example

import org.apache.log4j.{Level, Logger}
import org.apache.spark.{SparkConf, SparkContext}

import scala.io._
import scala.io.StdIn.readLine

object App {

  def main(args: Array[String]): Unit = {

    Logger.getLogger("org").setLevel(Level.OFF)
    Logger.getLogger("akka").setLevel(Level.OFF)

    val conf = new SparkConf().setAppName("AppName").setMaster("local[1]")
    val sc = new SparkContext(conf)

    def findMedian_Int (values : List[Int]): Int =
    {
      if (values.length % 2 == 0)
      {
        val right = values.length / 2
        val left = values.length / 2 - 1
        val median = (values(left) + values(right))/2
        return median
      }

      else
      {
        val median = values(values.length / 2)
        return median
      }
    }

    val data = sc.textFile("newFlights.csv").map(line => (line.split(",")(1).toInt, line.split(",").head.toInt))

    val n = Source.fromFile("newFlights.csv").getLines.length

    val x_mean = data.map(x => x._1).mean()
    val y_mean = data.map(y => y._2).mean()

    val x_sd = math.sqrt(data.map(x => math.pow(x._1 - x_mean, 2)).sum() / (n-1))
    val y_sd = math.sqrt(data.map(y => math.pow(y._2 - y_mean, 2)).sum() / (n-1))

    val x_as_list = data.map(x => x._1).collect().sortBy(x => x).toList
    val x_median = findMedian_Int(x_as_list)

    val y_as_list = data.map(y => y._2).collect().sortBy(y => y).toList
    val y_median = findMedian_Int(y_as_list)

    println("Number of Observations: " + n)
    println("x = Distance")
    println("y = Air Time")
    println("")

    println("Summary Statistics of Distance:")
    println("")
    println("Mean of Distance: " + x_mean)
    println("Standard Deviation of Distance: " + x_sd)
    println("Min of Distance: " + x_as_list.head)
    println("First Quartile of Distance: " + x_as_list((n * .25).toInt))
    println("Median of Distance: " + x_median)
    println("Third Quartile of Distance: " + x_as_list((n * .75).toInt))
    println("Max of Distance: " + x_as_list(n-1))

    println("")

    println("Summary Statistics of Air Time:")
    println("")
    println("Mean of Air Time: " + y_mean)
    println("Standard Deviation of Air Time: " + y_sd)
    println("Min of Air Time: " + y_as_list.head)
    println("First Quartile of Air Time: " + y_as_list((n * .25).toInt))
    println("Median of Air Time: " + y_median)
    println("Third Quartile of Air Time: " + y_as_list((n * .75).toInt))
    println("Max of Air Time: " + y_as_list(n-1))

    println("")

    val numerator = data.map(xy => (xy._1 - x_mean) * (xy._2 - y_mean)).sum()
    val denominator = math.sqrt(data.map(x => math.pow(x._1 - x_mean, 2)).sum()) * math.sqrt(data.map(y => math.pow(y._2 - y_mean, 2)).sum())

    val r = numerator / denominator

    val slope = r * (y_sd / x_sd)
    val intercept = y_mean - slope * x_mean

    println("Correlation: " + r)
    println("R-squared: " + r*r)

    println("predicted Air Time = " + slope + "(Distance) + " + intercept)

    val std_err_slope_numerator = data.map(y => math.pow(y._2 - (slope * y._2 + intercept), 2)).sum()
    val std_err_slope_denominator = data.map(x => math.pow(x._1 - x_mean, 2)).sum()
    val std_err_slope = math.sqrt((1.0/(n-2)) * (std_err_slope_numerator/std_err_slope_denominator))

    val t_star = 1.96020124

    println("Standard Error of the Slope: " + std_err_slope)
    println("95% Confidence Interval: " + "(" + (slope - (t_star * std_err_slope)) + " , " + (slope + (t_star * std_err_slope)) + ")")

    println("")
    println("")

//    The distance between LAX and Orlando is 2212 miles

    val answer = slope * 2212 + intercept
    println(slope + " (2212) + " + intercept + " = " + answer)

    val input_x = 2212
    val std_err_pred = 1 + (1.0/n) + (math.pow(input_x.toInt - x_mean, 2)/((n-1) * math.pow(x_sd, 2)))
    val yhat = slope * input_x.toInt + intercept

    println("95% Confidence Prediction Interval: " + "(" + (yhat - (t_star * std_err_pred)) + " , " + (yhat + (t_star * std_err_pred)) + ")")

  }

}